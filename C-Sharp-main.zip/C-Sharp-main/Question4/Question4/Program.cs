﻿Console.WriteLine("ENTER STIRNG:");
string x=Console.ReadLine();
x = x.Replace(" ", String.Empty);
Console.WriteLine(x);